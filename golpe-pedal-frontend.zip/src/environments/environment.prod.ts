export const environment = {
  production: true,
  apiUrl: 'https://golpepedal-production.up.railway.app/api'
};
