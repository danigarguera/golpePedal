export const environment = {
  production: false,
  apiUrl: 'https://golpepedal-production.up.railway.app/api'
};
